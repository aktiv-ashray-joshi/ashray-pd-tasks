from odoo import api, fields, models


class StockLocation(models.Model):
    """Extend stock.location to show available quantity in display name and sort by quantity."""
    _inherit = 'stock.location'

    # @api.depends('complete_name')
    # @api.depends_context('show_available_qty', 'product_id')
    def _compute_display_name(self):
        """Append available quantity to location display name when context keys are set.

        Builds from the stored ``complete_name`` field (always clean) rather
        than appending to ``display_name`` which may already carry a cached
        quantity suffix, preventing the ``(10.0) (10.0)`` duplication bug.
        """
        print('compute display name >>>>>>>>>>>>>>>>>>>>>>>', self, self._context)
        print('quant ', self.quant_ids.mapped('product_tmpl_id'))
        

        super()._compute_display_name()
        
        # If show_available_qty or product_id is missing, abort appending qty.
        if not self.env.context.get('show_available_qty') or not self.env.context.get('product_id'):
            print('not show_available_qty or not product_id')
            return

        product_id = self.env.context.get('product_id')
        if isinstance(product_id, (list, tuple)):
            product_id = product_id[0]
        print('product_id >>>>>>>>>>>>>>>>>>>>>>>', product_id)
        quants = self.env['stock.quant'].search([
        ('product_id', '=', product_id),
        ('location_id', 'in', self.ids),
        ])
        qty_by_loc = {}
        for q in quants:
            qty_by_loc[q.location_id.id] = (
                qty_by_loc.get(q.location_id.id, 0.0) + q.available_quantity
            )

        for location in self:
            available_qty = qty_by_loc.get(location.id, 0.0)
            print('available_qty >>>>>>>>>>>>>>>>>>>>>>>', available_qty)
            base = location.complete_name or location.name
            print('base >>>>>>>>>>>>>>>>>>>>>>>', base)
            location.display_name = f"{base} ({available_qty})"
            print('location.display_name >>>>>>>>>>>>>>>>>>>>>>>', location.display_name)

    # @api.model
    # def name_search(self, name='', domain=None, operator='ilike', limit=100):
    #     """Sort dropdown results by available quantity (highest first)."""
    #     res = super().name_search(name, domain, operator, limit)
    #     if self.env.context.get('show_available_qty') and self.env.context.get('product_id'):
    #         product_id = self.env.context.get('product_id')
    #         if isinstance(product_id, (list, tuple)):
    #             product_id = product_id[0]

    #         loc_ids = [r[0] for r in res]
    #         if loc_ids:
    #             quants = self.env['stock.quant'].search([
    #                 ('product_id', '=', product_id),
    #                 ('location_id', 'in', loc_ids),
    #             ])
    #             qty_by_loc = {}
    #             for q in quants:
    #                 qty_by_loc[q.location_id.id] = (
    #                     qty_by_loc.get(q.location_id.id, 0.0) + q.available_quantity
    #                 )
    #             res.sort(key=lambda r: qty_by_loc.get(r[0], 0.0), reverse=True)
    #     return res

    @api.model
    def search_fetch(self,domain,field_names=None,offset=0,limit=None,order=None):
        """Sort Search More results by available quantity (highest first)."""
        print("\n\n\n\n\n",'11111111111111111111111111111111111111')
        # First call base method
        res = super().search_fetch(
            domain,
            field_names=field_names,
            offset=offset,
            limit=limit,
            order=order,
        )

        # Apply custom sorting
        if (
            self.env.context.get('show_available_qty')
            and self.env.context.get('product_id')
            and res
        ):
            product_id = self.env.context.get('product_id')

            if isinstance(product_id, (list, tuple)):
                product_id = product_id[0]

            loc_ids = res.ids

            if loc_ids:
                quants = self.env['stock.quant'].search([
                    ('product_id', '=', product_id),
                    ('location_id', 'in', loc_ids),
                ])

                qty_by_loc = {}

                for q in quants:
                    qty_by_loc[q.location_id.id] = (
                        qty_by_loc.get(q.location_id.id, 0.0)
                        + q.available_quantity
                    )

                # Sort recordset
                res = res.sorted(
                    key=lambda r: qty_by_loc.get(r.id, 0.0),
                    reverse=True,
                )

        # Return result
        return res

    # @api.model
    # def web_search_read(self, domain=None, specification=None, offset=0,
    #                     limit=None, order=None, count_limit=None):
    #     """Sort 'Search More' dialog results by available quantity (highest first)."""
    #     result = super().web_search_read(
    #         domain, specification, offset=offset, limit=limit,
    #         order=order, count_limit=count_limit,
    #     )
    #     if self.env.context.get('show_available_qty') and self.env.context.get('product_id'):
    #         product_id = self.env.context.get('product_id')
    #         if isinstance(product_id, (list, tuple)):
    #             product_id = product_id[0]

    #         records = result.get('records', [])
    #         loc_ids = [r['id'] for r in records if 'id' in r]
    #         if loc_ids:
    #             quants = self.env['stock.quant'].search([
    #                 ('product_id', '=', product_id),
    #                 ('location_id', 'in', loc_ids),
    #             ])
    #             qty_by_loc = {}
    #             for q in quants:
    #                 qty_by_loc[q.location_id.id] = (
    #                     qty_by_loc.get(q.location_id.id, 0.0) + q.available_quantity
    #                 )
    #             records.sort(
    #                 key=lambda r: qty_by_loc.get(r.get('id'), 0.0),
    #                 reverse=True,
    #             )
    #     return result
