from odoo import api, fields, models

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    available_location_ids = fields.Many2many(
        comodel_name='stock.location',
        compute='_compute_available_location_ids',
        string='Available Locations',
    )

    location_id = fields.Many2one(
        comodel_name='stock.location',
        string='Source Location',
        domain="[('id', 'in', available_location_ids)]",
        ondelete='set null',
    )

    @api.depends('product_id')
    def _compute_available_location_ids(self):
        """Find all internal locations that have available stock for the product."""
        for line in self:
            if line.product_id:
                quant_ids = self.env['stock.quant'].search([
                    ('product_id', '=', line.product_id.id),
                    ('location_id.usage', '=', 'internal'),
                ]).filtered(lambda q: q.available_quantity > 0)
                print("\n\n\n\n\n",quant_ids)
                line.available_location_ids = quant_ids.mapped('location_id')
            else:
                line.available_location_ids = self.env['stock.location']

    @api.onchange('product_id')
    def _onchange_product_id_reset_location(self):
        """Reset location whenever the product changes."""
        self.location_id = False

    # @api.readonly
    # def web_read(self, specification):
    #     """Inject product context into location_id spec so display_name shows quantity."""
    #     product_ids_by_line = {}

    #     if 'location_id' in specification:
    #         for line in self:
    #             if line.product_id and line.location_id:
    #                 product_ids_by_line[line.id] = line.product_id.id

    #     result = super().web_read(specification)

    #     if 'location_id' in specification and product_ids_by_line:
    #         for rec_vals in result:
    #             loc_data = rec_vals.get('location_id')
    #             if not loc_data or not isinstance(loc_data, dict):
    #                 continue
    #             pid = product_ids_by_line.get(rec_vals.get('id'))
    #             if pid:
    #                 loc = self.env['stock.location'].with_context(
    #                     show_available_qty=True, product_id=pid,
    #                 ).browse(loc_data['id'])
    #                 loc_data['display_name'] = loc.display_name

    #     print('WEB READ RESULT', result)
    #     return result